Medical Icons for Vista

Product page:
http://www.777icons.com/libs/medical-vista-icons.htm
